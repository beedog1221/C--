#include "EntityManager.h"
using namespace eb;

entityManager::~entityManager() {
	
}

Entity entityManager::create_entity() {
	Entity next;
	return next;
}