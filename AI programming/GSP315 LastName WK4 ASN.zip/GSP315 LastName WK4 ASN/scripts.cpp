#include <iostream>
#include <Python.h>

using namespace std;
int main(int argc, char *argv[]) {
	
	// c++ code
	cout << " which type of pet do you prefer?\n";
	cout << "cats\n";
	cout << "dogs\n";
	
	///////////////////////////////////////////////////////
	
	//Python code
	print( "Which type of pet do you prefer?" )
	print( " cats" )
	print( " dogs" )
	
	input( '\n\nPress Enter to exit...' )
	
}