#include "state Machine.h"





public function chase() :void{

	Seek();
}



public function wander() :void{

	Wander();

}



public function update() :void{

}