/* Specification:
Braylin Jones - Mcmullen  
Lab 4 Exercise 1
This program does line of astrics  */

#include <iostream>
using namespace std;

void drawBar(int);
void printTriangle(int);


int main() 
{
     int lineSize = 0;
	 cout << "line" << endl;
	 cout << "line length: ";
	 cin >> lineSize;
	 cout << endl;
	 printTriangle(lineSize);
	 cout << endl << endl;
	return 0;
}

void drawBar(int star)
{
	for(int b = 1; b < star; b++)
		cout << "*";
	cout << endl;

}

void printTriangle(int line)
{
	
	for(int i = 0; i < line; i++)
		drawBar(line);
	
}